﻿
namespace CoopFood
{
    partial class fTrangChu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fTrangChu));
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2PnShowMenu = new Guna.UI2.WinForms.Guna2Panel();
            this.btnNhanVien = new Guna.UI2.WinForms.Guna2Button();
            this.btnQuanLyTaiKhoan = new Guna.UI2.WinForms.Guna2Button();
            this.btnTaiKhoan = new Guna.UI2.WinForms.Guna2Button();
            this.btnThongKe = new Guna.UI2.WinForms.Guna2Button();
            this.btnXuatHoaDon = new Guna.UI2.WinForms.Guna2Button();
            this.btnKhachHang = new Guna.UI2.WinForms.Guna2Button();
            this.btnDangXuat = new Guna.UI2.WinForms.Guna2Button();
            this.btnSanPham = new Guna.UI2.WinForms.Guna2Button();
            this.btnNhaCungCap = new Guna.UI2.WinForms.Guna2Button();
            this.btnTrangChu = new Guna.UI2.WinForms.Guna2Button();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2Panel2_Top = new Guna.UI2.WinForms.Guna2Panel();
            this.lbTenForm = new System.Windows.Forms.Label();
            this.guna2ControlClose = new Guna.UI2.WinForms.Guna2ControlBox();
            this.guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.guna2ShadowFormNhanVien = new Guna.UI2.WinForms.Guna2ShadowForm(this.components);
            this.Panel_Container = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel1.SuspendLayout();
            this.guna2PnShowMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.guna2Panel2_Top.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BackColor = System.Drawing.Color.White;
            this.guna2Panel1.Controls.Add(this.guna2PnShowMenu);
            this.guna2Panel1.Controls.Add(this.btnTaiKhoan);
            this.guna2Panel1.Controls.Add(this.btnThongKe);
            this.guna2Panel1.Controls.Add(this.btnXuatHoaDon);
            this.guna2Panel1.Controls.Add(this.btnKhachHang);
            this.guna2Panel1.Controls.Add(this.btnDangXuat);
            this.guna2Panel1.Controls.Add(this.btnSanPham);
            this.guna2Panel1.Controls.Add(this.btnNhaCungCap);
            this.guna2Panel1.Controls.Add(this.btnTrangChu);
            this.guna2Panel1.Controls.Add(this.guna2PictureBox1);
            this.guna2Panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel1.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(229, 765);
            this.guna2Panel1.TabIndex = 0;
            // 
            // guna2PnShowMenu
            // 
            this.guna2PnShowMenu.Controls.Add(this.btnNhanVien);
            this.guna2PnShowMenu.Controls.Add(this.btnQuanLyTaiKhoan);
            this.guna2PnShowMenu.Location = new System.Drawing.Point(61, 478);
            this.guna2PnShowMenu.Name = "guna2PnShowMenu";
            this.guna2PnShowMenu.Size = new System.Drawing.Size(168, 100);
            this.guna2PnShowMenu.TabIndex = 6;
            // 
            // btnNhanVien
            // 
            this.btnNhanVien.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnNhanVien.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnNhanVien.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnNhanVien.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnNhanVien.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnNhanVien.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnNhanVien.ForeColor = System.Drawing.Color.Black;
            this.btnNhanVien.HoverState.BorderColor = System.Drawing.Color.Black;
            this.btnNhanVien.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnNhanVien.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnNhanVien.Location = new System.Drawing.Point(3, 52);
            this.btnNhanVien.Name = "btnNhanVien";
            this.btnNhanVien.Size = new System.Drawing.Size(162, 45);
            this.btnNhanVien.TabIndex = 9;
            this.btnNhanVien.Text = "Thông tin nhân viên";
            this.btnNhanVien.Click += new System.EventHandler(this.guna2BtnNhanVien_Click);
            // 
            // btnQuanLyTaiKhoan
            // 
            this.btnQuanLyTaiKhoan.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnQuanLyTaiKhoan.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnQuanLyTaiKhoan.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnQuanLyTaiKhoan.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnQuanLyTaiKhoan.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnQuanLyTaiKhoan.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnQuanLyTaiKhoan.ForeColor = System.Drawing.Color.Black;
            this.btnQuanLyTaiKhoan.HoverState.BorderColor = System.Drawing.Color.Black;
            this.btnQuanLyTaiKhoan.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnQuanLyTaiKhoan.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnQuanLyTaiKhoan.Location = new System.Drawing.Point(3, 3);
            this.btnQuanLyTaiKhoan.Name = "btnQuanLyTaiKhoan";
            this.btnQuanLyTaiKhoan.Size = new System.Drawing.Size(162, 45);
            this.btnQuanLyTaiKhoan.TabIndex = 8;
            this.btnQuanLyTaiKhoan.Text = "Quản lý tài khoản";
            this.btnQuanLyTaiKhoan.Click += new System.EventHandler(this.guna2BtnQuanLy_Click);
            // 
            // btnTaiKhoan
            // 
            this.btnTaiKhoan.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 8);
            this.btnTaiKhoan.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnTaiKhoan.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnTaiKhoan.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnTaiKhoan.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnTaiKhoan.FillColor = System.Drawing.Color.Transparent;
            this.btnTaiKhoan.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTaiKhoan.ForeColor = System.Drawing.Color.Black;
            this.btnTaiKhoan.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.btnTaiKhoan.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnTaiKhoan.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnTaiKhoan.HoverState.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.btnTaiKhoan.Image = ((System.Drawing.Image)(resources.GetObject("btnTaiKhoan.Image")));
            this.btnTaiKhoan.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnTaiKhoan.ImageOffset = new System.Drawing.Point(0, -3);
            this.btnTaiKhoan.ImageSize = new System.Drawing.Size(25, 25);
            this.btnTaiKhoan.Location = new System.Drawing.Point(0, 430);
            this.btnTaiKhoan.Name = "btnTaiKhoan";
            this.btnTaiKhoan.Size = new System.Drawing.Size(229, 42);
            this.btnTaiKhoan.TabIndex = 7;
            this.btnTaiKhoan.Text = "Nhân viên";
            this.btnTaiKhoan.Click += new System.EventHandler(this.guna2BtnTaiKhoan_Click);
            // 
            // btnThongKe
            // 
            this.btnThongKe.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 8);
            this.btnThongKe.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnThongKe.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnThongKe.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnThongKe.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnThongKe.FillColor = System.Drawing.Color.Transparent;
            this.btnThongKe.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThongKe.ForeColor = System.Drawing.Color.Black;
            this.btnThongKe.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.btnThongKe.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnThongKe.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnThongKe.HoverState.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            this.btnThongKe.Image = ((System.Drawing.Image)(resources.GetObject("btnThongKe.Image")));
            this.btnThongKe.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnThongKe.ImageOffset = new System.Drawing.Point(0, -3);
            this.btnThongKe.ImageSize = new System.Drawing.Size(25, 25);
            this.btnThongKe.Location = new System.Drawing.Point(0, 382);
            this.btnThongKe.Name = "btnThongKe";
            this.btnThongKe.Size = new System.Drawing.Size(229, 42);
            this.btnThongKe.TabIndex = 6;
            this.btnThongKe.Text = "Thống kê";
            this.btnThongKe.Click += new System.EventHandler(this.guna2BtnThongKe_Click_1);
            // 
            // btnXuatHoaDon
            // 
            this.btnXuatHoaDon.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 8);
            this.btnXuatHoaDon.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnXuatHoaDon.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnXuatHoaDon.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnXuatHoaDon.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnXuatHoaDon.FillColor = System.Drawing.Color.Transparent;
            this.btnXuatHoaDon.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXuatHoaDon.ForeColor = System.Drawing.Color.Black;
            this.btnXuatHoaDon.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.btnXuatHoaDon.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnXuatHoaDon.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnXuatHoaDon.HoverState.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image2")));
            this.btnXuatHoaDon.Image = ((System.Drawing.Image)(resources.GetObject("btnXuatHoaDon.Image")));
            this.btnXuatHoaDon.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnXuatHoaDon.ImageOffset = new System.Drawing.Point(0, -3);
            this.btnXuatHoaDon.ImageSize = new System.Drawing.Size(25, 25);
            this.btnXuatHoaDon.Location = new System.Drawing.Point(0, 334);
            this.btnXuatHoaDon.Name = "btnXuatHoaDon";
            this.btnXuatHoaDon.Size = new System.Drawing.Size(229, 42);
            this.btnXuatHoaDon.TabIndex = 5;
            this.btnXuatHoaDon.Text = "Xuất hoá đơn";
            this.btnXuatHoaDon.Click += new System.EventHandler(this.guna2BtnXuatHoaDon_Click);
            // 
            // btnKhachHang
            // 
            this.btnKhachHang.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 8);
            this.btnKhachHang.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnKhachHang.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnKhachHang.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnKhachHang.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnKhachHang.FillColor = System.Drawing.Color.Transparent;
            this.btnKhachHang.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKhachHang.ForeColor = System.Drawing.Color.Black;
            this.btnKhachHang.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.btnKhachHang.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnKhachHang.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnKhachHang.HoverState.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image3")));
            this.btnKhachHang.Image = ((System.Drawing.Image)(resources.GetObject("btnKhachHang.Image")));
            this.btnKhachHang.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnKhachHang.ImageOffset = new System.Drawing.Point(0, -3);
            this.btnKhachHang.ImageSize = new System.Drawing.Size(25, 25);
            this.btnKhachHang.Location = new System.Drawing.Point(0, 286);
            this.btnKhachHang.Name = "btnKhachHang";
            this.btnKhachHang.Size = new System.Drawing.Size(229, 42);
            this.btnKhachHang.TabIndex = 4;
            this.btnKhachHang.Text = "Khách hàng";
            this.btnKhachHang.Click += new System.EventHandler(this.guna2BtnKhachHang_Click);
            // 
            // btnDangXuat
            // 
            this.btnDangXuat.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 8);
            this.btnDangXuat.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnDangXuat.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnDangXuat.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnDangXuat.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnDangXuat.FillColor = System.Drawing.Color.Transparent;
            this.btnDangXuat.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDangXuat.ForeColor = System.Drawing.Color.Black;
            this.btnDangXuat.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.btnDangXuat.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnDangXuat.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnDangXuat.HoverState.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image4")));
            this.btnDangXuat.Image = ((System.Drawing.Image)(resources.GetObject("btnDangXuat.Image")));
            this.btnDangXuat.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnDangXuat.ImageOffset = new System.Drawing.Point(2, -3);
            this.btnDangXuat.ImageSize = new System.Drawing.Size(25, 25);
            this.btnDangXuat.Location = new System.Drawing.Point(0, 700);
            this.btnDangXuat.Name = "btnDangXuat";
            this.btnDangXuat.Size = new System.Drawing.Size(229, 42);
            this.btnDangXuat.TabIndex = 10;
            this.btnDangXuat.Text = "Đăng xuất";
            this.btnDangXuat.Click += new System.EventHandler(this.btnDangXuat_Click);
            // 
            // btnSanPham
            // 
            this.btnSanPham.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 8);
            this.btnSanPham.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnSanPham.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnSanPham.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnSanPham.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnSanPham.FillColor = System.Drawing.Color.Transparent;
            this.btnSanPham.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSanPham.ForeColor = System.Drawing.Color.Black;
            this.btnSanPham.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.btnSanPham.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnSanPham.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnSanPham.HoverState.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image5")));
            this.btnSanPham.Image = ((System.Drawing.Image)(resources.GetObject("btnSanPham.Image")));
            this.btnSanPham.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnSanPham.ImageOffset = new System.Drawing.Point(0, -3);
            this.btnSanPham.ImageSize = new System.Drawing.Size(25, 25);
            this.btnSanPham.Location = new System.Drawing.Point(0, 190);
            this.btnSanPham.Name = "btnSanPham";
            this.btnSanPham.Size = new System.Drawing.Size(229, 42);
            this.btnSanPham.TabIndex = 2;
            this.btnSanPham.Text = "Sản phẩm";
            this.btnSanPham.Click += new System.EventHandler(this.guna2BtnSanPham_Click);
            // 
            // btnNhaCungCap
            // 
            this.btnNhaCungCap.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 8);
            this.btnNhaCungCap.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnNhaCungCap.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnNhaCungCap.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnNhaCungCap.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnNhaCungCap.FillColor = System.Drawing.Color.Transparent;
            this.btnNhaCungCap.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNhaCungCap.ForeColor = System.Drawing.Color.Black;
            this.btnNhaCungCap.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.btnNhaCungCap.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnNhaCungCap.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnNhaCungCap.HoverState.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image6")));
            this.btnNhaCungCap.Image = ((System.Drawing.Image)(resources.GetObject("btnNhaCungCap.Image")));
            this.btnNhaCungCap.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnNhaCungCap.ImageOffset = new System.Drawing.Point(0, -3);
            this.btnNhaCungCap.ImageSize = new System.Drawing.Size(25, 25);
            this.btnNhaCungCap.Location = new System.Drawing.Point(0, 238);
            this.btnNhaCungCap.Name = "btnNhaCungCap";
            this.btnNhaCungCap.Size = new System.Drawing.Size(229, 42);
            this.btnNhaCungCap.TabIndex = 3;
            this.btnNhaCungCap.Text = "Nhà cung cấp";
            this.btnNhaCungCap.Click += new System.EventHandler(this.guna2BtnNhaCungCap_Click);
            // 
            // btnTrangChu
            // 
            this.btnTrangChu.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 8);
            this.btnTrangChu.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnTrangChu.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnTrangChu.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnTrangChu.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnTrangChu.FillColor = System.Drawing.Color.Transparent;
            this.btnTrangChu.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrangChu.ForeColor = System.Drawing.Color.Black;
            this.btnTrangChu.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.btnTrangChu.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnTrangChu.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnTrangChu.HoverState.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image7")));
            this.btnTrangChu.Image = ((System.Drawing.Image)(resources.GetObject("btnTrangChu.Image")));
            this.btnTrangChu.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnTrangChu.ImageOffset = new System.Drawing.Point(0, -3);
            this.btnTrangChu.ImageSize = new System.Drawing.Size(25, 25);
            this.btnTrangChu.Location = new System.Drawing.Point(0, 142);
            this.btnTrangChu.Name = "btnTrangChu";
            this.btnTrangChu.Size = new System.Drawing.Size(229, 42);
            this.btnTrangChu.TabIndex = 1;
            this.btnTrangChu.Text = "Trang chủ";
            this.btnTrangChu.Click += new System.EventHandler(this.guna2BtnTrangChu_Click);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.Image = global::CoopFood.Properties.Resources.logo_coop_01;
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(-83, -32);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(364, 168);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox1.TabIndex = 0;
            this.guna2PictureBox1.TabStop = false;
            // 
            // guna2Panel2_Top
            // 
            this.guna2Panel2_Top.Controls.Add(this.lbTenForm);
            this.guna2Panel2_Top.Controls.Add(this.guna2ControlClose);
            this.guna2Panel2_Top.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel2_Top.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 1);
            this.guna2Panel2_Top.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Panel2_Top.FillColor = System.Drawing.Color.LimeGreen;
            this.guna2Panel2_Top.Location = new System.Drawing.Point(229, 0);
            this.guna2Panel2_Top.Name = "guna2Panel2_Top";
            this.guna2Panel2_Top.Size = new System.Drawing.Size(1098, 60);
            this.guna2Panel2_Top.TabIndex = 1;
            // 
            // lbTenForm
            // 
            this.lbTenForm.AutoSize = true;
            this.lbTenForm.BackColor = System.Drawing.Color.LimeGreen;
            this.lbTenForm.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTenForm.Location = new System.Drawing.Point(58, 22);
            this.lbTenForm.Name = "lbTenForm";
            this.lbTenForm.Size = new System.Drawing.Size(60, 23);
            this.lbTenForm.TabIndex = 2;
            this.lbTenForm.Text = "label1";
            this.lbTenForm.Visible = false;
            // 
            // guna2ControlClose
            // 
            this.guna2ControlClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlClose.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(152)))), ((int)(((byte)(166)))));
            this.guna2ControlClose.HoverState.FillColor = System.Drawing.Color.Red;
            this.guna2ControlClose.IconColor = System.Drawing.Color.White;
            this.guna2ControlClose.Location = new System.Drawing.Point(1030, 0);
            this.guna2ControlClose.Name = "guna2ControlClose";
            this.guna2ControlClose.Size = new System.Drawing.Size(68, 29);
            this.guna2ControlClose.TabIndex = 1;
            this.guna2ControlClose.Click += new System.EventHandler(this.guna2ControlBox1_Click);
            // 
            // guna2DragControl1
            // 
            this.guna2DragControl1.DockIndicatorTransparencyValue = 0.6D;
            this.guna2DragControl1.TargetControl = this.guna2Panel2_Top;
            this.guna2DragControl1.UseTransparentDrag = true;
            // 
            // Panel_Container
            // 
            this.Panel_Container.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel_Container.Location = new System.Drawing.Point(229, 60);
            this.Panel_Container.Name = "Panel_Container";
            this.Panel_Container.Size = new System.Drawing.Size(1098, 705);
            this.Panel_Container.TabIndex = 2;
            // 
            // fTrangChu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(1327, 765);
            this.Controls.Add(this.Panel_Container);
            this.Controls.Add(this.guna2Panel2_Top);
            this.Controls.Add(this.guna2Panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "fTrangChu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " ";
            this.Load += new System.EventHandler(this.fTrangChu_Load);
            this.guna2Panel1.ResumeLayout(false);
            this.guna2PnShowMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.guna2Panel2_Top.ResumeLayout(false);
            this.guna2Panel2_Top.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2_Top;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2Button btnTrangChu;
        private Guna.UI2.WinForms.Guna2Button btnDangXuat;
        private Guna.UI2.WinForms.Guna2Button btnTaiKhoan;
        private Guna.UI2.WinForms.Guna2Button btnSanPham;
        private Guna.UI2.WinForms.Guna2Button btnNhaCungCap;
        private Guna.UI2.WinForms.Guna2Panel guna2PnShowMenu;
        private Guna.UI2.WinForms.Guna2Button btnQuanLyTaiKhoan;
        private Guna.UI2.WinForms.Guna2Button btnThongKe;
        private Guna.UI2.WinForms.Guna2Button btnXuatHoaDon;
        private Guna.UI2.WinForms.Guna2Button btnKhachHang;
        private Guna.UI2.WinForms.Guna2ShadowForm guna2ShadowFormNhanVien;
        private Guna.UI2.WinForms.Guna2Button btnNhanVien;
        private Guna.UI2.WinForms.Guna2Panel Panel_Container;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlClose;
        private System.Windows.Forms.Label lbTenForm;
    }
}